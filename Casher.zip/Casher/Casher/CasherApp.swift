//
//  CasherApp.swift
//  Casher
//
//  Created by Ahmed Salah on 31/08/2024.
//

import SwiftUI

@main
struct CasherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
