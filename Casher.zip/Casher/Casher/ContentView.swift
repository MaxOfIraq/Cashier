import SwiftUI


struct ContentView: View {
    @State private var menuItems: [MenuItem] = [
        MenuItem(name: "Burger", price: 5000, imageName: "1"),
        MenuItem(name: "Pizza", price: 7000, imageName: "2"),
        MenuItem(name: "Samosa", price: 3000, imageName: "3"),
        MenuItem(name: "Takoyaki", price: 6500, imageName: "4"),
        MenuItem(name: "kintaki", price: 5000, imageName: "5"),
        MenuItem(name: "Pepsi", price: 500, imageName: "6"),
        MenuItem(name: "Shawarma", price: 4500, imageName: "7"),
        MenuItem(name: "Water", price: 500, imageName: "8")
    ]
    @State private var orderItems: [OrderItem] = []
    @State private var totalAmount: Double = 0.0
    @State private var selectedTableIndex: Int = 0
    @State private var customerName: String = ""
    @State private var customerPhone: String = ""
    @State private var dailyOrders: [TableOrder] = []
    @State private var showingOrdersWindow = false
    @State private var showingPasswordPrompt = false
    @State private var totalDailyEarnings: Double = 0.0
    @State private var discountPercentage: Double = 0.0
    @State private var selectedAdminIndex: Int = 0

    private let tableNames = ["Table 1","Table 2","Table 3","Table 4","Table 5"]
    private let adminNames = ["Ahmed Salah","Ali Salah"]
    private let adminPassword = "0"

    var body: some View {
        VStack {
            HStack {
                Text("Cashier")
                    .font(.largeTitle)
                    .padding(.top)

                Spacer()

                Text("Daily Earnings: د.ع \(totalDailyEarnings, specifier: "%.0f")")
                    .font(.headline)
                    .padding()
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(radius: 5)
            }
            .padding()

            HStack {
                Picker("Select Table", selection: $selectedTableIndex) {
                    ForEach(0..<tableNames.count) { index in
                        Text(tableNames[index])
                            .font(.headline)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                Button(action: openOrdersWindow) {
                    Text("View Orders")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .font(.headline)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
                .padding(.leading)
            }

            TextField("Customer Name", text: $customerName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            TextField("Customer Phone", text: $customerPhone)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Picker("Admin Name", selection: $selectedAdminIndex) {
                ForEach(0..<adminNames.count) { index in
                    Text(adminNames[index])
                        .font(.headline)
                        .padding()
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()

            HStack {
                Text("Discount: \(Int(discountPercentage))%")
                    .font(.headline)
                    .padding()

                Slider(value: $discountPercentage, in: 0...100, step: 1)
                    .padding()
            }

            ScrollView {
                GeometryReader { geometry in
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 160))], spacing: 20) {
                        ForEach(menuItems) { item in
                            MenuItemView(item: item) {
                                addToOrder(item)
                            }
                            .frame(width: (geometry.size.width - 40) / 2)
                        }
                    }
                    .padding()
                }
                .frame(height: 500)
            }

            VStack(alignment: .leading) {
                Text("Order Summary")
                    .font(.title2)
                    .padding(.horizontal)

                List(orderItems) { order in
                    Text(order.itemName)
                }

                HStack {
                    Text("Total: د.ع \(totalAmountWithDiscount, specifier: "%.0f")")
                        .font(.title)
                        .padding(.horizontal)

                    Spacer()

                    Button(action: clearOrder) {
                        Text("Clear Order")
                            .padding()
                            .background(Color.primary)
                            .foregroundColor(.white)
                            .font(.headline)
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }

                    Button(action: completeOrder) {
                        Text("Complete Order")
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .font(.headline)
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                }
                .padding(.horizontal)
            }

            HStack {
                Button(action: { showingPasswordPrompt = true }) {
                    Text("Delete All Orders")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .font(.headline)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
                .padding()
            }
        }
        .frame(minWidth: 400, minHeight: 600)
        .sheet(isPresented: $showingOrdersWindow) {
            OrdersWindow(dailyOrders: $dailyOrders, dismiss: { showingOrdersWindow = false }, updateDailyEarnings: updateDailyEarnings)
        }
        .sheet(isPresented: $showingPasswordPrompt) {
            PasswordPrompt(adminPassword: adminPassword) { isSuccess in
                if isSuccess {
                    deleteAllOrders()
                }
                showingPasswordPrompt = false
            }
        }
        .onAppear {
            loadOrders()
            updateDailyEarnings()
        }
    }

    private func addToOrder(_ item: MenuItem) {
        let orderItem = OrderItem(id: UUID(), itemName: item.name, price: item.price, timestamp: Date())
        orderItems.append(orderItem)
        totalAmount += item.price
    }

    private func clearOrder() {
        orderItems.removeAll()
        totalAmount = 0.0
    }

    private func completeOrder() {
        let tableName = tableNames[selectedTableIndex]
        let sessionID = UUID()

        let tableOrder = TableOrder(
            tableName: tableName,
            sessionID: sessionID,
            customerName: customerName,
            customerPhone: customerPhone,
            adminName: adminNames[selectedAdminIndex],
            orders: orderItems,
            discountPercentage: discountPercentage
        )
        dailyOrders.append(tableOrder)

        saveOrders()

        clearOrder()
        customerName = ""
        customerPhone = ""
        updateDailyEarnings()
    }

    private func openOrdersWindow() {
        showingOrdersWindow = true
    }

    private func saveOrders() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(dailyOrders) {
            UserDefaults.standard.set(encoded, forKey: "dailyOrders")
        }
    }

    private func loadOrders() {
        if let savedOrders = UserDefaults.standard.data(forKey: "dailyOrders") {
            let decoder = JSONDecoder()
            if let loadedOrders = try? decoder.decode([TableOrder].self, from: savedOrders) {
                dailyOrders = loadedOrders
                updateDailyEarnings()
            }
        }
    }
    
    private func deleteAllOrders() {
        dailyOrders.removeAll()
        saveOrders()
        updateDailyEarnings()
    }

    private func updateDailyEarnings() {
      
        totalDailyEarnings = dailyOrders.reduce(0) { total, order in
            let orderTotal = order.orders.reduce(0) { $0 + $1.price }
            let discountAmount = orderTotal * (order.discountPercentage / 100)
            return total + (orderTotal - discountAmount)
        }
    }

    private var totalAmountWithDiscount: Double {
        let discountAmount = totalAmount * (discountPercentage / 100)
        return totalAmount - discountAmount
    }
}


struct MenuItem: Identifiable {
    let id = UUID()
    let name: String
    let price: Double
    let imageName: String
}


struct OrderItem: Identifiable, Codable {
    let id: UUID
    let itemName: String
    let price: Double
    let timestamp: Date
}


struct TableOrder: Identifiable, Codable {
    let id = UUID()
    let tableName: String
    let sessionID: UUID
    let customerName: String
    let customerPhone: String
    let adminName: String
    let orders: [OrderItem]
    let discountPercentage: Double
}


struct MenuItemView: View {
    let item: MenuItem
    let addAction: () -> Void

    var body: some View {
        VStack {
            Image(item.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 120, height: 120)
                .cornerRadius(8)

            Text(item.name)
                .font(.headline)
                .padding(.top, 8)

            Text("Price: د.ع \(item.price, specifier: "%.0f")")
                .font(.subheadline)
                .padding(.bottom, 8)

            Button(action: addAction) {
                Text("Add to Order")
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(8)
        .shadow(radius: 5)
    }
}

struct OrdersWindow: View {
    @Binding var dailyOrders: [TableOrder]
    var dismiss: () -> Void
    var updateDailyEarnings: () -> Void

    var body: some View {
        VStack {
            HStack {
                Text("Orders")
                    .font(.largeTitle)
                    .padding(.top)

                Spacer()

                Button(action: dismiss) {
                    Text("Close")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .font(.headline)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                }
            }
            .padding()

            List {
                ForEach(dailyOrders) { order in
                    Section(header: Text(order.tableName)) {
                        ForEach(order.orders) { item in
                            Text("\(item.itemName) - \(item.price, specifier: "%.0f") د.ع")
                        }
                        Text("Customer: \(order.customerName)")
                        Text("Phone: \(order.customerPhone)")
                        Text("Admin: \(order.adminName)")
                        Text("Discount: \(Int(order.discountPercentage))%")
                        Text("Total: \(calculateOrderTotal(order: order), specifier: "%.0f") د.ع")
                    }
                }
            }
            .listStyle(DefaultListStyle())
        }
    }

    private func calculateOrderTotal(order: TableOrder) -> Double {
        let orderTotal = order.orders.reduce(0) { $0 + $1.price }
        let discountAmount = orderTotal * (order.discountPercentage / 100)
        return orderTotal - discountAmount
    }
}

struct PasswordPrompt: View {
    @State private var inputPassword = ""
    var adminPassword: String
    var onPasswordValidated: (Bool) -> Void

    var body: some View {
        VStack {
            Text("Enter Password")
                .font(.headline)
                .padding()

            SecureField("Password", text: $inputPassword)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            HStack {
                Button("Cancel") {
                    onPasswordValidated(false)
                }
                .padding()
                .background(Color.gray)
                .foregroundColor(.white)
                .cornerRadius(8)

                Button("Submit") {
                    onPasswordValidated(inputPassword == adminPassword)
                }
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
        }
        .padding()
    }
}



#Preview {
    ContentView()
}

